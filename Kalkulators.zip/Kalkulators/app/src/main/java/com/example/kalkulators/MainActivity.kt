package com.example.kalkulators

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var screen: TextView

    private var angkaPertama = 0.0
    private var operasi: String? = null
    private var inputBaru = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val rootView: View = findViewById(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { v: View, insets: WindowInsetsCompat ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        screen = findViewById(R.id.txtScreen)

        // Tombol angka 0 - 9
        val angkaBtn = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )

        angkaBtn.forEach { id ->
            val btn = findViewById<Button>(id)
            btn.setOnClickListener { view: View ->
                val value = (view as Button).text.toString()
                if (inputBaru) {
                    screen.text = value
                    inputBaru = false
                } else {
                    screen.text = screen.text.toString() + value
                }
            }
        }

        // Titik / koma
        findViewById<Button>(R.id.btnPoint).setOnClickListener { _: View ->
            if (!screen.text.contains(".")) {
                screen.text = screen.text.toString() + "."
            }
        }

        // Operator
        findViewById<Button>(R.id.btnAdd).setOnClickListener { _: View -> setOperasi("+") }
        findViewById<Button>(R.id.btnSubtract).setOnClickListener { _: View -> setOperasi("-") }
        findViewById<Button>(R.id.btnMultiply).setOnClickListener { _: View -> setOperasi("*") }
        findViewById<Button>(R.id.btnDivide).setOnClickListener { _: View -> setOperasi("/") }

        // Persen
        findViewById<Button>(R.id.btnPercent).setOnClickListener { _: View ->
            if (screen.text.isNotEmpty()) {
                val hasil = screen.text.toString().toDoubleOrNull()
                if (hasil != null) screen.text = (hasil / 100).toString()
            }
        }

        // Akar
        findViewById<Button>(R.id.btnSqrt).setOnClickListener { _: View ->
            if (screen.text.isNotEmpty()) {
                val v = screen.text.toString().toDoubleOrNull()
                if (v != null && v >= 0) screen.text = sqrt(v).toString() else screen.text = "Error"
            }
        }

        // Delete
        findViewById<Button>(R.id.btnDelete).setOnClickListener { _: View ->
            val text = screen.text.toString()
            if (text.isNotEmpty()) screen.text = text.dropLast(1)
        }

        // Clear
        findViewById<Button>(R.id.btnClear).setOnClickListener { _: View ->
            screen.text = ""
            angkaPertama = 0.0
            operasi = null
            inputBaru = false
        }

        // Equals
        findViewById<Button>(R.id.btnEquals).setOnClickListener { _: View ->
            if (operasi == null || screen.text.isEmpty()) return@setOnClickListener

            val angkaKedua = screen.text.toString().toDoubleOrNull()
            if (angkaKedua == null) {
                screen.text = "Error"
                operasi = null
                return@setOnClickListener
            }

            val hasil: Any = when (operasi) {
                "+" -> angkaPertama + angkaKedua
                "-" -> angkaPertama - angkaKedua
                "*" -> angkaPertama * angkaKedua
                "/" -> if (angkaKedua != 0.0) angkaPertama / angkaKedua else "Error"
                else -> "Error"
            }

            screen.text = hasil.toString()
            operasi = null
        }
    }

    private fun setOperasi(op: String) {
        if (screen.text.isNotEmpty()) {
            val current = screen.text.toString().toDoubleOrNull()
            if (current != null) {
                angkaPertama = current
                operasi = op
                inputBaru = true
            }
        }
    }
}
